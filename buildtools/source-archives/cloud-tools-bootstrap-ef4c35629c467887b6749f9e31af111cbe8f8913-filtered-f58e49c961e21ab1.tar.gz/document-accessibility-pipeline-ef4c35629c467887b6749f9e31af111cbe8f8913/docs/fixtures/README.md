# Synthetic fixture planning

The general remediation manifest describes planned characterization work; its rows do not contain PDF artifacts or assert observed preservation results. It is versioned at [`manifest.v1.json`](remediation/manifest.v1.json).

The bounded, equal-priority statement/invoice table operation is specified separately in the [financial-table experiment protocol v1](remediation/financial-table-experiment.v1.md). Its actual synthetic artifacts and observations are recorded independently; the four planned rows in the general manifest remain planned and not run.

The [financial-table experiment protocol v2](remediation/financial-table-experiment.v2.md) records separate metric-complete PDF 2.0 inputs for a later bounded feasibility attempt. V2 preserves the same two table cases and target association defect while adding the complete pinned Helvetica metrics from the outset. The independent text/render observations and exact metric evidence are versioned separately. This is fixture preparation only; no v2 writer operation, repair, candidate, or validator result is claimed.

The pre-spike A package is recorded in [`financial-table-experiment.v1.json`](remediation/financial-table-experiment.v1.json), with two normative positive PDFs and two derived inputs under [`financial-tables/`](remediation/financial-tables/). Each input has an immutable SHA-256, exact displayed strings, fixture-authored header IDs/associations and reading order, support boundaries, exclusions, and independent observations. Poppler `pdftotext` supplies text evidence, Ghostscript supplies the rendered-page digest, and pdfcpu-based Go checks verify `/IDTree`, `/Headers`, and MCID-to-content/ParentTree bindings. The damaged inputs change one target data-cell `/Headers` ID only; amounts, text, rendering, other associations, and order remain unchanged. Tool versions, commands, exit statuses, and hashes are in [`observations.v1.json`](remediation/financial-tables/observations/observations.v1.json); retained text and PNG outputs sit beside it. The IDTree/content negative controls execute in Go tests; amount-change, malformed, unsupported, and ambiguous controls remain defined for the later repair stage. No table-specific veraPDF result, repair result, product support, or conformance claim is made.

The exact v1 pdfcpu v0.16.2 API, reachable dependencies/assets, build settings, notices, and configuration boundary are recorded in the [financial-table clearance record](../research/pdfcpu-financial-table-clearance-2026-10-13.md). That clearance is limited to the reviewed v1 input and operation boundary; v2 requires the separate exact-input review described in its protocol before any writer operation.

Run `scripts/observe-financial-fixtures.sh` to reproduce text and render observations, and `go test ./internal/financialfixtures` to check retained observation hashes, PDF identities, and the positive/damaged structure predicates.

The v1 manifest maps one planned synthetic case to each family and references the corresponding synthetic remediation profile example. All cases are marked `planned-not-created` and `not-run`. Listed dimensions are items to assess for applicability and evidence; they are not expected values or promises that every fixture contains each feature.

Run `go test ./internal/corpus` to parse and validate the tracked manifest and exercise rejection cases.

The Go validator rejects unknown fields, non-synthetic provenance, unplanned artifacts, incomplete family or requirement coverage, duplicate IDs, and unsafe or mismatched profile paths. It validates planning metadata only. It does not generate, open, compare, or validate PDFs. Future malformed, scanned, or mixed-content cases must also be synthetic and remain proposed until safely authored and characterized.

This slice supports [REQ-REM-001 through REQ-REM-003](../requirements/catalog.md) and Beads issues `dap-jo9.1.1`, `dap-jo9.1.2`, and `dap-jo9.2.1`. Their profile and writer feasibility gates remain open.
